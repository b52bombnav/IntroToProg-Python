#-------------------------------------------------#
# Title: Working with Lists and Dictionaries
# Dev:   J. Vanover
# Date:  5/5/2019
# ChangeLog: (Who, When, What)
#   J.Vanover, 5/5/2019, Created script
# Note: modified from a starter script provided by
# R.Root at UW
#-------------------------------------------------#
# Data
objFile = "C:\_PythonClass\Assignment06\Todo.txt"  # location of Todo list
strData = "" # blank data
dicRow = {}  # empty dictionary
lstTable = []  # empty list

# Processing
class todo_Manager(object):  # To Do List Manager is set as a Class
    @staticmethod
    def display_Data(lstTable):  # display the current To Do list
        print("*** The Current ToDo list contains  ***")
        for row in lstTable:  # loop through each row
            print(row["Task"] + "(" + row["Priority"] + ")") # print each item
            print("***************************************")
        return

    @staticmethod
    def insert_Data(dicRow, lstTable):  # insert data into the To Do list and return the new table
        new_Item = str(input("Enter the new Task: ")).strip() # prompt for item and remove the \n
        new_Priority = str(input("Enter the task's priority as high or low: ")).strip()  # prompt for priority and remove the \n
        dicRow = {"Task":new_Item,"Priority":new_Priority}  # add item to dictionary
        lstTable.append(dicRow) # append the new item and priority to the table
        print("The Item was added to the table. \n")  # confirmation message
        return dicRow, lstTable  # return the dictionary and table

    @staticmethod
    def delete_Data(lstTable):  # delete data from txt file
        todo_Manager.display_Data(lstTable)  # display table data
        rem_Item = input("\nType the name of the item you want to remove: ") # prompt for the item to remove
        for i in range(len(lstTable)): # loop through table to find the item
            if lstTable[i]["Task"].lower() == rem_Item.lower():  # check for item
                del lstTable[i]  # delete the item and its priroity
                print("\n" + rem_Item + " was removed from the list.  Remember to save the table.") # confirmation
                break
        return lstTable  # return the dictionary and table

    @staticmethod
    def save_Data(dicRow, lstTable):  # Save Data to text file
        todo_Manager.display_Data(lstTable)  # display table data
        print("\nSaving data to file", objFile,"\n") # confirmation of where it is saving to
        file=open(objFile,"w")  # open file to append data
        for dicRow in lstTable: # loop through table
                file.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n") # save each row
        file.close()   # close the file
        print("The table has been saved to :" + objFile)  # conformation
        return  # return

# Load data from text file
def load_Data(objFile, dicRow, lstTable):
#        print(objFile, dicRow, lstTable)  # debug print statement
        file=open(objFile,"r")  # open file to read data from
        for line in file:  # read each line in the file
            strData=line.split(",")  # split the row into left and right by div at ","
            dicRow={"Task":strData[0].strip(),"Priority":strData[1].strip()}# strip off the \n
            lstTable.append(dicRow)  # append the read in data to the table
        file.close()  # close the file
        return dicRow, lstTable

# Display
def menu_Display():
        while(True):
            print ("""
            Menu of Options
            1) Show current data
            2) Add a new item.
            3) Remove an existing item.
            4) Save Data to File
            5) Exit Program
            """)
            strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
            print()#adding a new line

            if (strChoice.strip() == '1'):  # option 1 = Show current Data
                todo_Manager.display_Data(lstTable)

            elif(strChoice.strip() == '2'):  # option 2 = Add data to table
                todo_Manager.insert_Data(dicRow, lstTable)

            elif(strChoice == '3'):  # option 3 = Delete data from table
                todo_Manager.delete_Data(lstTable)

            elif(strChoice == '4'):  # option 4 = Save the data to a file
                todo_Manager.save_Data(dicRow, lstTable)

            elif (strChoice == '5'):  # option 5 = Exit Program
                break  # end the program

# main
print("       Welcome to the To Do List Manager\n")
load_Data(objFile, dicRow, lstTable)  # load the current ToDo list File
menu_Display()   # display menu and perform operations until user quits program
