#-------------------------------------------------#
# Title: Working with Exceptions and Pickling
# Dev:   J. Vanover
# Date:  5/13/2019
# ChangeLog: (Who, When, What)
#   J.Vanover, 5/13/2019, Created script
#
#-------------------------------------------------#

# setup
import pickle  # import pickle library
strData = "" # blank data
dicRow = {}  # empty dictionary
lstTable = []  # empty list
file_Data = [] # empty list to hold pickle load

# Exception section
print("Exception Example\n")
while True:  # Loop until correct file name is given
    objFile = input("Enter the file to load data from: ")
    try:  # Try user input
        file1 = open(objFile,"r")  # open file to read data from
        for line in file1: # read each line in the file
            strData = line.split(",")  # split the row into left and right by div at ","
            dicRow = {"Task":strData[0].strip(),"Priority":strData[1].strip()}# strip off the \n
            lstTable.append(dicRow)  # append the read in data to the table
        file1.close()  # close the file

    except FileNotFoundError:  # if user file not found print error message
        print("File " + objFile + " was not found!")
    else: # after file is found print message and clean up file
        print("File " + objFile + " was loaded")
        file1.close()  # close the file
        break # break out of loop

# Display what was loaded
print("*** The Current ToDo list contains  ***")
for row in lstTable:  # loop through each row
    print(row["Task"] + "(" + row["Priority"] + ")") # print each item
    print("***************************************")

# Pickling Section
print("\nPickling Example\n")
# Asker user what name to same the data to in binary format
# This uses the data loaded from Todo.txt
pic_File = input("Enter the name to save the binary file as: ")
file2 = open(pic_File, "ab")  # open file for binary append
pickle.dump(lstTable, file2)  # dump contents
file2.close()   # close append

# load data back in from binary file for viewing
file3 = open(pic_File, "rb")  # open file for binary read
print("Load Binary data back in for viewing.\n")
# use same file that was created above
while True:  # loop until file is at the end of file
    try: # try to load
        file_Data += pickle.load(file3)
        print("file loaded", file_Data)
    except EOFError as e:  # End of file error
        print("End of file found")
    else: # clean up after load is complete
        file3.close()
        break # break from loop

